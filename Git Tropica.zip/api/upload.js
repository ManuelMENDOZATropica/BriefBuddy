// api/upload.js
import { google } from "googleapis";
import OpenAI from "openai";
import formidable from "formidable";
import fs from "fs/promises";


export const config = {
  api: { bodyParser: false },
  runtime: "nodejs",
};

// ——— Helpers env ———
function required(name) {
  const v = process.env[name];
  if (!v) throw new Error(`Missing env: ${name}`);
  return v;
}

// ——— Google Auth/Drive ———
function oauthClient() {
  const oauth = new google.auth.OAuth2(
    required("GOOGLE_CLIENT_ID"),
    required("GOOGLE_CLIENT_SECRET"),
    required("GOOGLE_REDIRECT_URI")
  );
  oauth.setCredentials({ refresh_token: required("GOOGLE_REFRESH_TOKEN") });
  return oauth;
}

function driveClient() {
  const auth = oauthClient();
  return google.drive({ version: "v3", auth });
}


function parseMultipart(req) {
  return new Promise((resolve, reject) => {
    const form = formidable({
      multiples: false,
      keepExtensions: true,
      maxFileSize: 100 * 1024 * 1024, // 100MB
      // opcional: forzar directorio temporal conocido
      // uploadDir: os.tmpdir(),
    });

    form.parse(req, async (err, fields, files) => {
      try {
        if (err) return reject(err);

        // 1) Obtén el primer archivo sin suponer el nombre del campo
        let f =
          files.file ??
          files.upload ??
          files.attachment ??
          Object.values(files)[0];

        // 2) Si es arreglo, toma el primero
        if (Array.isArray(f)) f = f[0];

        // 3) Si no hay archivo o no trae ruta, salimos sin romper
        if (!f || (!f.filepath && !f.filepath?.length)) {
          return resolve({ fields, file: null });
        }

        // 4) Lee a buffer desde el filepath temporal
        const buffer = await fs.readFile(f.filepath);

        resolve({
          fields,
          file: {
            buffer,
            filename: f.originalFilename || f.newFilename || "upload",
            mimeType: f.mimetype || "application/octet-stream",
          },
        });
      } catch (e) {
        reject(e);
      }
    });
  });
}


// ——— Extractores ———
async function extractText({ buffer, mimeType }) {
  try {
    if (mimeType === "application/pdf") {
      const pdfParse = (await import("pdf-parse")).default;
      const data = await pdfParse(buffer);
      return data.text || "";
    }
    if (
      mimeType ===
      "application/vnd.openxmlformats-officedocument.wordprocessingml.document"
    ) {
      const mammoth = await import("mammoth");
      const { value } = await mammoth.extractRawText({ buffer });
      return value || "";
    }
    return "";
  } catch (err) {
    console.error("extractText error:", err);
    return "";
  }
}

function briefPrompt(texto, nombreArchivo, link) {
  return [
    { role: "system", content: "Eres un PM creativo. Devuelve SOLO JSON válido." },
    {
      role: "user",
      content: `
Archivo del cliente:
- Nombre: ${nombreArchivo}
- Link Drive: ${link}

Texto extraído:
"""
${(texto || "").slice(0, 12000)}
"""

Tarea:
1) Devuelve JSON con:
{
  "contacto": { "nombre": "", "correo": "" },
  "alcance": "",
  "objetivos": [],
  "audiencia": { "descripcion": "", "canales": [] },
  "marca": { "tono": "", "valores": [], "referencias": [] },
  "entregables": [],
  "logistica": { "fechas": [], "presupuesto": null, "aprobaciones": [] },
  "extras": { "riesgos": [], "notas": [] },
  "faltantes": [],
  "siguiente_pregunta": ""
}
2) Rellena solo si estás seguro; no inventes.
3) "faltantes" = campos importantes que faltan.
4) "siguiente_pregunta" = UNA pregunta clara para avanzar.
      `.trim(),
    },
  ];
}

// ——— Handler principal ———
export default async function handler(req, res) {
  try {
    if (req.method !== "POST") {
      return res.status(405).json({ error: "Method not allowed" });
    }

    required("OPENAI_API_KEY");
    required("DRIVE_FOLDER_ID");

    const { file } = await parseMultipart(req);
    if (!file) return res.status(400).json({ error: "No file" });

    // 1) Subir a Drive
    const drive = driveClient();
    const { Readable } = await import("stream");
    const stream = new Readable({
      read() {
        this.push(file.buffer);
        this.push(null);
      },
    });

    const upload = await drive.files.create({
      requestBody: {
        name: file.filename,
        parents: [process.env.DRIVE_FOLDER_ID],
      },
      media: { mimeType: file.mimeType, body: stream },
      fields: "id,name,mimeType,webViewLink",
    });

    // Hacerlo visible por link
    try {
      await drive.permissions.create({
        fileId: upload.data.id,
        requestBody: { role: "reader", type: "anyone" },
      });
    } catch (permErr) {
      console.warn("permissions.create warning:", permErr?.message || permErr);
    }

    const { data: meta } = await drive.files.get({
      fileId: upload.data.id,
      fields: "id,name,mimeType,webViewLink",
    });

    const driveLink = meta.webViewLink;

    // 2) Extraer texto + normalizar con OpenAI
    const text = await extractText(file);
    const openai = new OpenAI({ apiKey: process.env.OPENAI_API_KEY });

    const ai = await openai.chat.completions.create({
      model: "gpt-4o-mini",
      temperature: 0.2,
      messages: briefPrompt(text, file.filename, driveLink),
      response_format: { type: "json_object" },
    });

    let brief = {};
    try {
      brief = JSON.parse(ai.choices?.[0]?.message?.content || "{}");
    } catch (jerr) {
      console.warn("JSON parse warn:", jerr);
      brief = {};
    }

    return res.status(200).json({
      drive: { id: meta.id, name: meta.name, link: driveLink, mimeType: meta.mimeType },
      brief,
    });
  } catch (e) {
    console.error("upload handler error:", e?.response?.data || e);
    const message = e?.response?.data?.error || e?.message || "Upload error";
    return res.status(500).json({ error: message });
  }
}
